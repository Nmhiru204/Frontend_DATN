"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { LayoutDashboard, Package, Users, LogOut } from "lucide-react";
import Link from "next/link";

export default function AdminDashboard() {
  const [role, setRole] = useState<string | null>(null);
  const router = useRouter();

  useEffect(() => {
    const userRole = localStorage.getItem("role");
    setRole(userRole);

    // ❌ Nếu không phải admin thì chặn
    if (userRole !== "admin") {
      alert("🚫 Bạn không có quyền truy cập trang này!");
      router.push("/");
    }
  }, [router]);

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    router.push("/auth");
  };

  return (
    <div className="flex min-h-screen bg-gray-50 text-gray-800">
      {/* Sidebar */}
      <aside className="w-64 bg-black text-white flex flex-col p-6">
        <h1 className="text-2xl font-bold mb-8 tracking-tight">
          Admin<span className="text-gray-400">Panel</span>
        </h1>

        <nav className="flex flex-col gap-3 text-sm">
          <Link
            href="/admin"
            className="flex items-center gap-3 rounded-xl px-3 py-2 hover:bg-gray-800 transition"
          >
            <LayoutDashboard className="h-4 w-4" />
            Tổng quan
          </Link>

          <Link
            href="/admin/products"
            className="flex items-center gap-3 rounded-xl px-3 py-2 hover:bg-gray-800 transition"
          >
            <Package className="h-4 w-4" />
            Quản lý sản phẩm
          </Link>

          <Link
            href="/admin/users"
            className="flex items-center gap-3 rounded-xl px-3 py-2 hover:bg-gray-800 transition"
          >
            <Users className="h-4 w-4" />
            Quản lý người dùng
          </Link>
        </nav>

        <button
          onClick={handleLogout}
          className="mt-auto flex items-center gap-2 rounded-xl px-3 py-2 text-sm text-gray-300 hover:bg-gray-800 transition"
        >
          <LogOut className="h-4 w-4" />
          Đăng xuất
        </button>
      </aside>

      {/* Main content */}
      <main className="flex-1 p-8">
        <h2 className="text-3xl font-semibold mb-6">Bảng điều khiển</h2>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          {/* Card thống kê */}
          <div className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm hover:shadow-md transition">
            <p className="text-gray-500 text-sm mb-1">Tổng sản phẩm</p>
            <h3 className="text-2xl font-bold">128</h3>
          </div>

          <div className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm hover:shadow-md transition">
            <p className="text-gray-500 text-sm mb-1">Tổng người dùng</p>
            <h3 className="text-2xl font-bold">57</h3>
          </div>

          <div className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm hover:shadow-md transition">
            <p className="text-gray-500 text-sm mb-1">Đơn hàng trong tháng</p>
            <h3 className="text-2xl font-bold">24</h3>
          </div>
        </div>

        {/* Bảng mẫu */}
        <div className="mt-10 rounded-2xl border border-gray-200 bg-white shadow-sm">
          <div className="border-b border-gray-100 px-6 py-4 flex justify-between items-center">
            <h3 className="font-semibold">Hoạt động gần đây</h3>
            <button className="text-sm text-gray-500 hover:text-black transition">
              Xem tất cả
            </button>
          </div>

          <table className="w-full text-sm text-left text-gray-600">
            <thead className="bg-gray-50 text-gray-500 uppercase text-xs">
              <tr>
                <th className="px-6 py-3">Người dùng</th>
                <th className="px-6 py-3">Hành động</th>
                <th className="px-6 py-3">Thời gian</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-t">
                <td className="px-6 py-3 font-medium text-gray-900">Đàm Kiến Đạt</td>
                <td className="px-6 py-3">Thêm sản phẩm mới</td>
                <td className="px-6 py-3 text-gray-500">2 phút trước</td>
              </tr>
              <tr className="border-t">
                <td className="px-6 py-3 font-medium text-gray-900">Admin</td>
                <td className="px-6 py-3">Cập nhật đơn hàng #234</td>
                <td className="px-6 py-3 text-gray-500">1 giờ trước</td>
              </tr>
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
}
