export const products = [
  {
    id: 1,
    name: "Magic Watch Classic",
    price: "$249",
    image: "/watch1.jpg",
  },
  {
    id: 2,
    name: "Magic Watch Sport",
    price: "$299",
    image: "/watch2.jpg",
  },
  {
    id: 3,
    name: "Magic Watch Pro",
    price: "$399",
    image: "/watch3.jpg",
  },
];
